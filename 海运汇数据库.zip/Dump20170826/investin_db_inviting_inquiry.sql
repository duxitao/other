-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 210.209.123.148    Database: investin_db
-- ------------------------------------------------------
-- Server version	5.6.35-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `inviting_inquiry`
--

DROP TABLE IF EXISTS `inviting_inquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inviting_inquiry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `info_id` int(11) DEFAULT NULL,
  `field_id` int(11) DEFAULT NULL,
  `inquiry_email` varchar(45) DEFAULT NULL COMMENT '询问人邮箱',
  `content` varchar(2000) DEFAULT NULL,
  `requires1` varchar(200) DEFAULT NULL,
  `requires2` varchar(200) DEFAULT NULL,
  `requires3` varchar(200) DEFAULT NULL,
  `content_en` varchar(2000) DEFAULT NULL,
  `requires1_en` varchar(200) DEFAULT NULL,
  `requires2_en` varchar(200) DEFAULT NULL,
  `requires3_en` varchar(200) DEFAULT NULL,
  `status` varchar(1) DEFAULT '0' COMMENT '0-新建；1-确认；2-再次确认；3-需发送邮件；4-邮件已发送完成',
  `group_send` varchar(1) DEFAULT '0' COMMENT '是否群发邮件，0-否，1-是',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inviting_inquiry`
--

LOCK TABLES `inviting_inquiry` WRITE;
/*!40000 ALTER TABLE `inviting_inquiry` DISABLE KEYS */;
INSERT INTO `inviting_inquiry` VALUES (14,21,-1,'348570914@qq.com','   在测试中','需要项目的相关图片，如实拍照片、证明文件等。','需要详细全面的项目数据信息。','去项目方国家考察能全程接待。','we are try to text you','can we link you','how to fund ','','4','0','2017-02-04 23:49:53'),(15,21,-1,'348570914@qq.com','   我大多数大是大非 是否是   ',NULL,'需要详细全面的项目数据信息。',NULL,NULL,NULL,NULL,NULL,'0','1','2017-02-06 21:59:14'),(16,29,-1,'348570914@qq.com','   值得投资','需要项目的相关图片，如实拍照片、证明文件等。','需要详细全面的项目数据信息。','去项目方国家考察能全程接待。','3333fasdfa ','111111111111','1222222222222','222233333333333333','4','1','2017-02-07 21:50:28'),(18,21,-1,'348570914@qq.com','   需测试测试',NULL,'需要详细全面的项目数据信息。','去项目方国家考察能全程接待。','what about the test result','ceshi1','ceshi2','ceshi3','4','1','2017-02-09 21:49:55'),(19,20,-1,'348570914@qq.com','  考察多少时间','需要项目的相关图片，如实拍照片、证明文件等。','需要详细全面的项目数据信息。',NULL,'how logn to get the information ','not long','good ','nice','4','1','2017-02-09 21:55:52'),(22,24,-1,'duxitao@126.com','   ','需要项目的相关图片，如实拍照片、证明文件等。','需要详细全面的项目数据信息。','去项目方国家考察能全程接待。',NULL,NULL,NULL,NULL,'0','0','2017-02-12 22:32:56'),(23,36,-1,'duxitao@126.com','大项目回复','','','',NULL,NULL,NULL,NULL,'0','0','2017-02-12 22:56:21'),(24,29,-1,'duxitao@126.com','非常好','需要项目的相关图片，如实拍照片、证明文件等。','需要详细全面的项目数据信息。','去项目方国家考察能全程接待。',NULL,NULL,NULL,NULL,'0','0','2017-02-12 23:04:22'),(25,25,4,'348570914@qq.com','我会来你们国家考察的','需要项目的相关图片，如实拍照片、证明文件等。','需要详细全面的项目数据信息。','去项目方国家考察能全程接待。','I would have to visit your country','11111','2222','','4','1','2017-02-14 21:42:00'),(26,42,-1,'348570914@qq.com','我们是一家发电厂，有兴趣在非洲拓展业务。联系电话13688888888','','','',NULL,NULL,NULL,NULL,'0','0','2017-02-14 21:55:39'),(27,24,-1,'348570914@qq.com','dffdhfghfhf','需要项目的相关图片，如实拍照片、证明文件等。','需要详细全面的项目数据信息。','去项目方国家考察能全程接待。',NULL,NULL,NULL,NULL,'0','1','2017-02-22 18:29:00'),(28,42,-1,'348570914@qq.com','hgfhfhfghf','','','',NULL,NULL,NULL,NULL,'0','0','2017-02-22 18:29:25'),(29,24,-1,'348570914@qq.com','我们非常需要这个项目，请告知具体情况。','需要项目的相关图片，如实拍照片、证明文件等。','需要详细全面的项目数据信息。','去项目方国家考察能全程接待。',NULL,NULL,NULL,NULL,'0','0','2017-02-22 19:17:14'),(30,24,-1,'348570914@qq.com','我们想获得这个项目，请告知详情。','需要项目的相关图片，如实拍照片、证明文件等。','需要详细全面的项目数据信息。','去项目方国家考察能全程接待。','we want to ge this project, pls let me know it soon.','','','','4','0','2017-02-22 19:18:45'),(31,45,-1,'348570914@qq.com','非常好，我们可以供应卡车，不是问题','需要项目的相关图片，如实拍照片、证明文件等。','需要详细全面的项目数据信息。','去项目方国家考察能全程接待。',NULL,NULL,NULL,NULL,'0','0','2017-02-23 18:36:19'),(32,45,-1,'348570914@qq.com','非常好，我们可以供应卡车，不是问题','需要项目的相关图片，如实拍照片、证明文件等。','需要详细全面的项目数据信息。','去项目方国家考察能全程接待。','yes, we can supply a truck, it cheap and good quality, and the most important thing is that we want to invest in africa, invest a plant for truck repair factory. ','show me your certificate\'ID','joint verture company is poriority','','4','0','2017-02-23 18:39:11'),(33,25,-1,'348570914@qq.com','继续测试','需要项目的相关图片，如实拍照片、证明文件等。','需要详细全面的项目数据信息。','去项目方国家考察能全程接待。',' this is the way we test furthermore.','really test','further test','','4','0','2017-02-23 19:08:34'),(34,20,-1,'348570914@qq.com','继续测试','需要项目的相关图片，如实拍照片、证明文件等。','需要详细全面的项目数据信息。','去项目方国家考察能全程接待。','go on to test it furthermore','test it','further test ','','4','0','2017-02-23 19:12:51'),(35,21,-1,'348570914@qq.com','有没有收到邮件','需要项目的相关图片，如实拍照片、证明文件等。','需要详细全面的项目数据信息。','去项目方国家考察能全程接待。','didi you receive it','test 1','test 2','','4','0','2017-02-23 19:18:16'),(36,21,-1,'348570914@qq.com','有没有收到邮件','需要项目的相关图片，如实拍照片、证明文件等。','需要详细全面的项目数据信息。','去项目方国家考察能全程接待。','didi you receive it','','','','4','0','2017-02-23 19:19:23'),(37,21,0,'348570914@qq.com','非常好，谢谢合作','需要项目的相关图片，如实拍照片、证明文件等。','需要详细全面的项目数据信息。','去项目方国家考察能全程接待。',NULL,NULL,NULL,NULL,'0','1','2017-03-03 09:42:07'),(38,24,0,'348570914@qq.com','我们想投资一千万','需要项目的相关图片，如实拍照片、证明文件等。','需要详细全面的项目数据信息。','去项目方国家考察能全程接待。','dear sir, i am really interested to your business, since i am runing business in china, i think yours is matched,we want to expand our business to africa, mutiple sections, i think you can be my partner as well as anchor, so i would like to discuss with you furthermore, concerning investment solution and cooperated method, soonest reply is appreciated. thanks','pls show your company\'s license','','','4','0','2017-04-04 17:53:40'),(43,24,-1,'348570914@qq.com','价格比较就','需要项目的相关图片，如实拍照片、证明文件等。','需要详细全面的项目数据信息。','去项目方国家考察能全程接待。',NULL,NULL,NULL,NULL,'0','0','2017-04-20 18:56:37'),(44,53,-1,'348570914@qq.com','项目情况如何','需要项目的相关图片，如实拍照片、证明文件等。','需要详细全面的项目数据信息。','去项目方国家考察能全程接待。',NULL,NULL,NULL,NULL,'0','0','2017-04-23 16:50:05'),(45,82,-1,'1991777659@qq.com','印刷好多类   主要是什么印刷','需要项目的相关图片，如实拍照片、证明文件等。','需要详细全面的项目数据信息。','去项目方国家考察能全程接待。',NULL,NULL,NULL,NULL,'0','0','2017-07-31 23:26:58');
/*!40000 ALTER TABLE `inviting_inquiry` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-26 23:41:15
