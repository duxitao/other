-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 210.209.123.148    Database: investin_db
-- ------------------------------------------------------
-- Server version	5.6.35-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `inviting_inquiry_account`
--

DROP TABLE IF EXISTS `inviting_inquiry_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inviting_inquiry_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(45) DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `reg_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` char(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `tel_UNIQUE` (`tel`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inviting_inquiry_account`
--

LOCK TABLES `inviting_inquiry_account` WRITE;
/*!40000 ALTER TABLE `inviting_inquiry_account` DISABLE KEYS */;
INSERT INTO `inviting_inquiry_account` VALUES (7,'zjun1977@126.com',NULL,NULL,'2017-01-27 11:53:44','0'),(8,'duxitao110@qq.com',NULL,NULL,'2017-02-02 23:32:55','0'),(9,'duxitao@126.com',NULL,NULL,'2017-02-03 14:24:31','0'),(10,'348570914@qq.com',NULL,NULL,'2017-02-04 23:49:00','0'),(11,'2850177471@qq.com',NULL,NULL,'2017-04-01 17:16:13','0'),(12,'2549413867@qq.com',NULL,NULL,'2017-04-05 18:25:09','0'),(13,'630158445@qq.com',NULL,NULL,'2017-04-07 11:23:07','0'),(14,'2850177477@qq.com',NULL,NULL,'2017-04-11 14:28:30','0'),(15,'513894882@qq.com',NULL,NULL,'2017-04-15 00:49:50','0'),(16,'379913291@qq.com',NULL,NULL,'2017-05-03 10:22:09','0'),(17,'12115685@qq.com',NULL,NULL,'2017-06-04 15:09:06','0'),(18,'862760707@qq.com',NULL,NULL,'2017-06-20 22:45:40','0'),(19,'chinebao@163.com',NULL,NULL,'2017-07-17 14:48:21','0'),(20,'2784900934@qq.com',NULL,NULL,'2017-07-23 09:03:40','0'),(21,'1991777659@qq.com',NULL,NULL,'2017-07-31 23:25:43','0'),(22,'18635768@qq.com',NULL,NULL,'2017-08-07 13:23:20','0');
/*!40000 ALTER TABLE `inviting_inquiry_account` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-26 23:41:33
