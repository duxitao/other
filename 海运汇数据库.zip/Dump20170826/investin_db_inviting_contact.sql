-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 210.209.123.148    Database: investin_db
-- ------------------------------------------------------
-- Server version	5.6.35-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `inviting_contact`
--

DROP TABLE IF EXISTS `inviting_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inviting_contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `countryId` int(11) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `message` varchar(200) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inviting_contact`
--

LOCK TABLES `inviting_contact` WRITE;
/*!40000 ALTER TABLE `inviting_contact` DISABLE KEYS */;
INSERT INTO `inviting_contact` VALUES (6,3,'how to pay','i want to pay for it, and get a credit code right now.','jack','56464757','348570914@qq.com','2017-02-22 18:48:47'),(7,5,'i want to submit','i want to submiti want to submiti want to submiti want to submiti want to submiti want to submiti want to submiti want to submiti want to submiti want to submit','david','5476754','348570914@qq.com','2017-02-22 18:52:27'),(8,5,'submition','Hi, I tried to submit in the network but was not able to','veronica njeri','+254725271491','veronjeriomosh@gmail.com','2017-03-10 17:21:31'),(9,3,'Re:request for founding for mineral projects','Hello,\r\n\r\nWe are looking for the found urgently to pay for tankfarm for 5 working days and we are willing to 20% net profit this is very urgently project and we have already clients and contracta.','Dr. Anthony Mandjolo','+37814476399','anthony.mmgti@gmail.com','2017-04-05 04:45:07'),(10,3,'Funding','Looking for funding ','Colin Hendra','+27 832391642','colin.hendra25@gmail.com','2017-04-05 15:58:55'),(11,3,'Green House Farming','We are planning to invest in the growing of quality vegetables on a large scale and distribute it widely in Mauritius or even export in to other countries.  \r\nDo you have any investors?','Navish ','+2304676200','navishcampusabroad@gmail.com','2017-04-06 20:06:02'),(12,5,'user accounts','we would like to be logging in once so that we dont keep generating codes from our emails each time we want to use the site..\r\nthanks','Dennis','+254705419531','dennismukah@gmail.com','2017-04-06 20:29:53'),(13,3,'Non gmo white maize','Request for funding ','David Mosoeu','+27824088701','delacasatrading564@gmail.com','2017-04-08 03:25:44'),(14,3,'funding','I have the ability too do great things I only need a corporate investor.','Mohammed Adam','+2731 736763845','totallyunique1@gmail.com','2017-04-10 20:53:03'),(15,3,'funding','Please let\'s put this too bed I have deals lined up.','Mohammed Adam','+2731 736763845','totallyunique1@gmail.com','2017-04-10 21:24:24'),(16,3,'funding','Hi please look at my application we can make a great deal of money.I\'m committed 100%','Mohammed Adam','+2731 736763845','totallyunique1@gmail.com','2017-04-11 11:31:05'),(17,5,'Account opening','Kindly assist me to register and create an account with you','Purity Njambi ','0727929239','njambipurity5@gmail.com','2017-04-26 19:56:41'),(18,5,'loan applications','Wanted to log in yet not yet sign up. What do I do?','Victor sijenyi','+254715055108','volwande8@gmail.com','2017-05-12 05:32:05'),(19,5,'HOW DOES THIS WORK','I WANTED A CLARIFICATION ON HOW THIS SITE WORK PLEASE.','MUNGE','0734352575','mungegathuri@gmail.com','2017-05-16 23:49:18');
/*!40000 ALTER TABLE `inviting_contact` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-26 23:41:22
