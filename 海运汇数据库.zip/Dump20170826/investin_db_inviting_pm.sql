-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 210.209.123.148    Database: investin_db
-- ------------------------------------------------------
-- Server version	5.6.35-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `inviting_pm`
--

DROP TABLE IF EXISTS `inviting_pm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inviting_pm` (
  `method_en` varchar(50) NOT NULL,
  `method_es` varchar(45) DEFAULT NULL,
  `pm_id` varchar(50) DEFAULT NULL,
  `coverage` varchar(50) DEFAULT NULL,
  `sort` int(11) DEFAULT '0',
  PRIMARY KEY (`method_en`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inviting_pm`
--

LOCK TABLES `inviting_pm` WRITE;
/*!40000 ALTER TABLE `inviting_pm` DISABLE KEYS */;
INSERT INTO `inviting_pm` VALUES ('Almacenes Exito','Almacenes Exito','exito_co','Colombia',0),('American Express Colombia','American Express Colombia','americanexpress_co','Colombia',0),('Baloto','Baloto','baloto_co','Colombia',0),('banamex','banamex','banamex_mx','Mexico',0),('Banco de Occidente','Banco de Occidente','oc_co','Colombia',0),('bancomer','bancomer','bancomer_mx','Mexico',0),('Carulla','Carulla','carulla_co','Colombia',0),('Davivienda','Davivienda','davivienda_co','Colombia',0),('debit card (visa or mastercard)','debit card (visa or mastercard)','debitcard_mx','Mexico',0),('Diners Club Colombia','Diners Club Colombia','dinersclub_co','Colombia',0),('EDEQ','EDEQ','edeq_co','Colombia',0),('Efecty','Efecty','efecty_co','Colombia',0),('MasterCard Colombia','MasterCard Colombia','mastercard_co','Colombia',0),('MasterCard Debit Colombia','MasterCard Debit Colombia','mastercarddebit_co','Colombia',0),('oxxo','oxxo','oxxo_mx','Mexico',0),('PSE','PSE','pse_co','Colombia',0),('santander','santander','santander_mx','Mexico',0),('Sofort','Sofort','sofort','Colombia',0),('Surtimax','Surtimax','surtimax_co','Colombia',0),('Visa Colombia','Visa Colombia','visadebit_co','Colombia',0);
/*!40000 ALTER TABLE `inviting_pm` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-26 23:41:12
