-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 210.209.123.148    Database: investin_db
-- ------------------------------------------------------
-- Server version	5.6.35-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `inviting_basedata`
--

DROP TABLE IF EXISTS `inviting_basedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inviting_basedata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` char(1) DEFAULT NULL COMMENT '1-国家数据；2-行业数据；3-代表数据；',
  `code` varchar(10) DEFAULT NULL,
  `name_zh` varchar(100) DEFAULT NULL,
  `name_en` varchar(100) DEFAULT NULL,
  `name_es` varchar(100) DEFAULT NULL,
  `tel` varchar(45) DEFAULT NULL,
  `add` varchar(100) DEFAULT NULL,
  `order_num` int(11) DEFAULT '1',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8 COMMENT='基础数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inviting_basedata`
--

LOCK TABLES `inviting_basedata` WRITE;
/*!40000 ALTER TABLE `inviting_basedata` DISABLE KEYS */;
INSERT INTO `inviting_basedata` VALUES (1,'2','F3','汽摩、交通运输','Autos y transporte','Autos y transporte','','',103,'2017-02-02 17:00:16',NULL),(2,'2','F4','箱包、鞋靴及配饰','Bags, Shoes & Accessories','Carteras, Zapatos y Complementos','','',104,'2017-02-02 17:02:31',NULL),(3,'1','C1','南非','South africa',NULL,'','',1,'2017-02-02 17:02:57',NULL),(4,'2','F2','服装、纺织及配饰','Apparel,Textiles&Accessories','Ropa, Textiles y Accesorios','','',102,'2017-02-02 19:48:32',NULL),(5,'1','C2','肯尼亚','Kenya',NULL,'','',2,'2017-02-02 19:53:17',NULL),(6,'2','F1','农业、食品','Agricuture&Food','Agricultura y Alimentos','','',101,'2017-02-02 21:19:28',NULL),(7,'2','F5','电子产品','Electronics','Electrónicos','','',105,'2017-02-02 21:43:23',NULL),(8,'2','F6','电气设备、通讯及元件','Electrical Equipment, Components & Telecoms','Equipos Eléctricos, Components y Telecomunicaciones','','',106,'2017-02-02 21:43:48',NULL),(9,'2','F7','礼品、运动、玩具','Gifts, Sports & Toys','Regalos, Deportes y Juguetería','','',107,'2017-02-02 21:44:12',NULL),(10,'2','F8','健康美容、个护家清','Health & Beauty','Salud y Belleza','','',108,'2017-02-02 21:44:46',NULL),(11,'2','F9','家纺家饰、家装建材','Home, Lights & Construction','Hogar, Luces y Construcción','','',109,'2017-02-02 21:45:04',NULL),(12,'2','F10','机械设备、工业部件及工具','Machinery, Industrial Parts & Tools','Maquinaria, Partes Industriales y Herramientas','','',110,'2017-02-02 21:46:12',NULL),(13,'2','F11','冶金、矿产、化工','Metallurgy, Mineral, Chemicals','Metalurgia, Minerales, Químicos','','',111,'2017-02-02 21:46:43',NULL),(14,'2','F12','包装、广告、办公','Packaging, Advertising & Office','Empaques, Publicidad y Oficina','','',112,'2017-02-02 21:47:18',NULL),(15,'2','F13','服务、外包','Service&outsourcing','Servicios y Outsourcing','','',113,'2017-02-02 21:47:42',NULL),(30,'1','C3','坦桑尼亚','Tanzania',NULL,'','',3,'2017-02-10 14:36:39',NULL),(31,'1','C4','赞比亚','Zambia',NULL,'','',4,'2017-02-10 14:36:45',NULL),(32,'1','C5','尼日利亚','Nigeria',NULL,'','',5,'2017-02-10 14:41:32',NULL),(33,'1','C6','埃塞俄比亚','Ethiopia',NULL,'','',6,'2017-02-10 14:42:48',NULL),(34,'1','C7','乌干达','Uganda',NULL,'','',7,'2017-02-10 14:44:57',NULL),(35,'1','C8','安哥拉','Angola',NULL,'','',8,'2017-02-10 14:46:40',NULL),(36,'4','E3','@126.com','@126.com',NULL,'','',303,'2017-02-14 22:53:04',NULL),(37,'4','E2','@163.com','@163.com',NULL,'','',302,'2017-02-14 23:40:45',NULL),(38,'4','E1','@qq.com','@qq.com',NULL,'','',301,'2017-02-14 23:40:45',NULL),(48,'4','E8','@yeah.net','@yeah.net',NULL,'','',308,'2017-02-16 19:09:40',NULL),(49,'4','E6','@sina.com','@sina.com',NULL,'','',306,'2017-02-16 19:11:04',NULL),(50,'4','E7','@sina.cn','@sina.cn',NULL,'','',307,'2017-02-16 19:11:33',NULL),(51,'4','E4','@139.com','@139.com',NULL,'','',304,'2017-02-16 19:12:56',NULL),(52,'4','E5','@sohu.com','@sohu.com',NULL,'','',305,'2017-02-16 19:14:31',NULL),(53,'1','C20','哥伦比亚','Colombia','Colombia','','',20,'2017-03-10 20:36:57',NULL),(54,'1','C21','厄瓜多尔','Ecuador','Ecuador','','',21,'2017-03-10 20:38:48',NULL),(55,'1','C22','秘鲁','Peru','Perú','','',22,'2017-03-10 20:39:31',NULL),(57,'1','C9','津巴布韦','Zimbabwe',NULL,'','',9,'2017-04-05 17:28:29',NULL),(58,'1','C10','博茨瓦纳','Botswana',NULL,'','',10,'2017-04-05 17:29:35',NULL),(59,'1','C11','斯威士兰','Switzerland',NULL,'','',11,'2017-04-05 17:31:01',NULL),(60,'1','C12','莫桑比克','Mozambique',NULL,'','',12,'2017-04-05 17:31:45',NULL),(61,'1','C13','刚果（金）','Congo,Democratic Republic',NULL,'','',13,'2017-04-05 17:34:22',NULL),(62,'1','C14','马拉维','Malawi',NULL,'','',14,'2017-04-05 17:35:22',NULL),(63,'1','C15','科特迪瓦','Ivory coast',NULL,'','',15,'2017-04-05 17:37:26',NULL),(64,'1','C16','埃及','Egypt',NULL,'','',16,'2017-04-05 17:38:01',NULL);
/*!40000 ALTER TABLE `inviting_basedata` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-26 23:41:21
